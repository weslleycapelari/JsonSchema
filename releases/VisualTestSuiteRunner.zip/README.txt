================================================================================
VisualTestSuiteRunner - JSON Schema Test Suite compliance visual runner.
================================================================================

This package contains both the Command-Line Interface (CLI) and the VCL Desktop
GUI version of the tool.

FILE LIST:
  - VisualTestSuiteRunnerCLI.exe : Command-Line Interface
  - VisualTestSuiteRunnerVCL.exe : Desktop GUI Application
  - README.txt          : This guide

--------------------------------------------------------------------------------
1. How to run the CLI version
--------------------------------------------------------------------------------
Open your command prompt or terminal and run:
  VisualTestSuiteRunnerCLI.exe -i <suite_dir> [-d <draft>] [-o <output_json>] [--quiet]

--------------------------------------------------------------------------------
2. How to run the VCL GUI version
--------------------------------------------------------------------------------
Double-click:
  VisualTestSuiteRunnerVCL.exe

================================================================================
