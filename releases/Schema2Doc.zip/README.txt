================================================================================
Schema2Doc - Markdown/HTML documentation generator from JSON Schema.
================================================================================

This package contains both the Command-Line Interface (CLI) and the VCL Desktop
GUI version of the tool.

FILE LIST:
  - Schema2DocCLI.exe : Command-Line Interface
  - Schema2DocVCL.exe : Desktop GUI Application
  - README.txt          : This guide

--------------------------------------------------------------------------------
1. How to run the CLI version
--------------------------------------------------------------------------------
Open your command prompt or terminal and run:
  Schema2DocCLI.exe -s <schema_path> [-o <output_path>] [-f <format>] [-t <title>]

--------------------------------------------------------------------------------
2. How to run the VCL GUI version
--------------------------------------------------------------------------------
Double-click:
  Schema2DocVCL.exe

================================================================================
