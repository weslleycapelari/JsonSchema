================================================================================
Schema2Delphi - Delphi DTO class generator from JSON Schema.
================================================================================

This package contains both the Command-Line Interface (CLI) and the VCL Desktop
GUI version of the tool.

FILE LIST:
  - Schema2DelphiCLI.exe : Command-Line Interface
  - Schema2DelphiVCL.exe : Desktop GUI Application
  - README.txt          : This guide

--------------------------------------------------------------------------------
1. How to run the CLI version
--------------------------------------------------------------------------------
Open your command prompt or terminal and run:
  Schema2DelphiCLI.exe -s <schema_path> -u <unit_name> -c <class_name> [-o <output_path>]

--------------------------------------------------------------------------------
2. How to run the VCL GUI version
--------------------------------------------------------------------------------
Double-click:
  Schema2DelphiVCL.exe

================================================================================
