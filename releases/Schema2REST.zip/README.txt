================================================================================
Schema2REST - Horse/DMVC REST router and controller generator from JSON Schema.
================================================================================

This package contains both the Command-Line Interface (CLI) and the VCL Desktop
GUI version of the tool.

FILE LIST:
  - Schema2RESTCLI.exe : Command-Line Interface
  - Schema2RESTVCL.exe : Desktop GUI Application
  - README.txt          : This guide

--------------------------------------------------------------------------------
1. How to run the CLI version
--------------------------------------------------------------------------------
Open your command prompt or terminal and run:
  Schema2RESTCLI.exe -s <schema_path> [-f <framework>] [-o <output_path>] [-e <entity_name>]

--------------------------------------------------------------------------------
2. How to run the VCL GUI version
--------------------------------------------------------------------------------
Double-click:
  Schema2RESTVCL.exe

================================================================================
