================================================================================
SchemaValidator - JSON Schema validator utility.
================================================================================

This package contains both the Command-Line Interface (CLI) and the VCL Desktop
GUI version of the tool.

FILE LIST:
  - SchemaValidatorCLI.exe : Command-Line Interface
  - SchemaValidatorVCL.exe : Desktop GUI Application
  - README.txt          : This guide

--------------------------------------------------------------------------------
1. How to run the CLI version
--------------------------------------------------------------------------------
Open your command prompt or terminal and run:
  SchemaValidatorCLI.exe -s <schema_path> [-i <instance_path>] [-d <draft>] [-l <locale>] [-f <format>]

--------------------------------------------------------------------------------
2. How to run the VCL GUI version
--------------------------------------------------------------------------------
Double-click:
  SchemaValidatorVCL.exe

================================================================================
