================================================================================
Schema2DDL - Relational SQL DDL script generator from JSON Schema.
================================================================================

This package contains both the Command-Line Interface (CLI) and the VCL Desktop
GUI version of the tool.

FILE LIST:
  - Schema2DDLCLI.exe : Command-Line Interface
  - Schema2DDLVCL.exe : Desktop GUI Application
  - README.txt          : This guide

--------------------------------------------------------------------------------
1. How to run the CLI version
--------------------------------------------------------------------------------
Open your command prompt or terminal and run:
  Schema2DDLCLI.exe -s <schema_path> [-d <dialect>] [-o <output_path>] [-t <table_name>] [--drop] [--no-auto-inc] [-q]

--------------------------------------------------------------------------------
2. How to run the VCL GUI version
--------------------------------------------------------------------------------
Double-click:
  Schema2DDLVCL.exe

================================================================================
