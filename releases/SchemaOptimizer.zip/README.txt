================================================================================
SchemaOptimizer - JSON Schema simplification and optimization utility.
================================================================================

This package contains both the Command-Line Interface (CLI) and the VCL Desktop
GUI version of the tool.

FILE LIST:
  - SchemaOptimizerCLI.exe : Command-Line Interface
  - SchemaOptimizerVCL.exe : Desktop GUI Application
  - README.txt          : This guide

--------------------------------------------------------------------------------
1. How to run the CLI version
--------------------------------------------------------------------------------
Open your command prompt or terminal and run:
  SchemaOptimizerCLI.exe -i <input_path> [-o <output_path>] [options]

--------------------------------------------------------------------------------
2. How to run the VCL GUI version
--------------------------------------------------------------------------------
Double-click:
  SchemaOptimizerVCL.exe

================================================================================
