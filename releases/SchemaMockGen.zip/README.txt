================================================================================
SchemaMockGen - Data mock generator for JSON Schema.
================================================================================

This package contains both the Command-Line Interface (CLI) and the VCL Desktop
GUI version of the tool.

FILE LIST:
  - SchemaMockGenCLI.exe : Command-Line Interface
  - SchemaMockGenVCL.exe : Desktop GUI Application
  - README.txt          : This guide

--------------------------------------------------------------------------------
1. How to run the CLI version
--------------------------------------------------------------------------------
Open your command prompt or terminal and run:
  SchemaMockGenCLI.exe -s <schema_path> [-o <output_path>] [-n <count>] [-seed <seed>]

--------------------------------------------------------------------------------
2. How to run the VCL GUI version
--------------------------------------------------------------------------------
Double-click:
  SchemaMockGenVCL.exe

================================================================================
