================================================================================
SchemaBundler - JSON Schema packaging utility.
================================================================================

This package contains both the Command-Line Interface (CLI) and the VCL Desktop
GUI version of the tool.

FILE LIST:
  - SchemaBundlerCLI.exe : Command-Line Interface
  - SchemaBundlerVCL.exe : Desktop GUI Application
  - README.txt          : This guide

--------------------------------------------------------------------------------
1. How to run the CLI version
--------------------------------------------------------------------------------
Open your command prompt or terminal and run:
  SchemaBundlerCLI.exe -i <input_path> [-o <output_path>] [--legacy] [--minify]

--------------------------------------------------------------------------------
2. How to run the VCL GUI version
--------------------------------------------------------------------------------
Double-click:
  SchemaBundlerVCL.exe

================================================================================
