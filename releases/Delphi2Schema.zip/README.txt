================================================================================
Delphi2Schema - JSON Schema generator from Delphi classes/records using RTTI.
================================================================================

This package contains both the Command-Line Interface (CLI) and the VCL Desktop
GUI version of the tool.

FILE LIST:
  - Delphi2SchemaCLI.exe : Command-Line Interface
  - Delphi2SchemaVCL.exe : Desktop GUI Application
  - README.txt          : This guide

--------------------------------------------------------------------------------
1. How to run the CLI version
--------------------------------------------------------------------------------
Open your command prompt or terminal and run:
  Delphi2SchemaCLI.exe -t <type_name> [-b <bpl_path>] [-o <output_path>] [--no-enum-names]

--------------------------------------------------------------------------------
2. How to run the VCL GUI version
--------------------------------------------------------------------------------
Double-click:
  Delphi2SchemaVCL.exe

================================================================================
