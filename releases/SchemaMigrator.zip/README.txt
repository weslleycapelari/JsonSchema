================================================================================
SchemaMigrator - JSON Schema draft version migration utility.
================================================================================

This package contains both the Command-Line Interface (CLI) and the VCL Desktop
GUI version of the tool.

FILE LIST:
  - SchemaMigratorCLI.exe : Command-Line Interface
  - SchemaMigratorVCL.exe : Desktop GUI Application
  - README.txt          : This guide

--------------------------------------------------------------------------------
1. How to run the CLI version
--------------------------------------------------------------------------------
Open your command prompt or terminal and run:
  SchemaMigratorCLI.exe -i <input_path> [-o <output_path>] [--minify]

--------------------------------------------------------------------------------
2. How to run the VCL GUI version
--------------------------------------------------------------------------------
Double-click:
  SchemaMigratorVCL.exe

================================================================================
