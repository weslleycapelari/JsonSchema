================================================================================
SchemaLinter - JSON Schema static quality and security analyzer.
================================================================================

This package contains both the Command-Line Interface (CLI) and the VCL Desktop
GUI version of the tool.

FILE LIST:
  - SchemaLinterCLI.exe : Command-Line Interface
  - SchemaLinterVCL.exe : Desktop GUI Application
  - README.txt          : This guide

--------------------------------------------------------------------------------
1. How to run the CLI version
--------------------------------------------------------------------------------
Open your command prompt or terminal and run:
  SchemaLinterCLI.exe -s <schema_path> [-o <output_path>] [-m <min_severity>]

--------------------------------------------------------------------------------
2. How to run the VCL GUI version
--------------------------------------------------------------------------------
Double-click:
  SchemaLinterVCL.exe

================================================================================
